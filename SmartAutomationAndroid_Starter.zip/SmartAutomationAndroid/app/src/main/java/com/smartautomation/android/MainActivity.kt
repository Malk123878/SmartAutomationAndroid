package com.smartautomation.android

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.room.Room
import com.smartautomation.android.data.*
import com.smartautomation.android.browser.EmbeddedBrowser
import com.smartautomation.android.automation.UrlPlatformDetector
import kotlinx.coroutines.launch
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = Room.databaseBuilder(applicationContext, SmartDatabase::class.java, "smart_automation.db").build()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { SmartApp(db) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SmartApp(db: SmartDatabase) {
    var tab by remember { mutableStateOf("الرئيسية") }
    val profiles by db.profiles().observeAll().collectAsState(initial = emptyList())
    val tasks by db.tasks().observeAll().collectAsState(initial = emptyList())
    val logs by db.logs().observeRecent().collectAsState(initial = emptyList())
    var showAddProfile by remember { mutableStateOf(false) }
    var browserUrl by remember { mutableStateOf("https://www.google.com") }
    var taskTitle by remember { mutableStateOf("") }
    var taskUrl by remember { mutableStateOf("") }
    var selectedPlatform by remember { mutableStateOf("auto") }
    var selectedActions by remember { mutableStateOf(setOf("comment")) }
    val scope = rememberCoroutineScope()

    Scaffold(topBar = { TopAppBar(title = { Text("SmartAutomation") }) }, bottomBar = {
        NavigationBar { listOf("الرئيسية", "الحسابات", "المهام", "المتصفح", "السجلات").forEach { item ->
            NavigationBarItem(selected = tab == item, onClick = { tab = item }, icon = {}, label = { Text(item) })
        } }
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            when (tab) {
                "الرئيسية" -> {
                    Text("لوحة التحكم", style = MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.height(16.dp))
                    Text("الحسابات: ${profiles.size}")
                    Text("المهام: ${tasks.size}")
                    Text("السجلات: ${logs.size}")
                    Spacer(Modifier.height(12.dp))
                    Text("التنفيذ في هذه النسخة الأولية لم يُفعّل بعد. المتصفح اليدوي وإدارة البيانات هما أساس المرحلة الأولى.")
                }
                "الحسابات" -> {
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("الحسابات", style = MaterialTheme.typography.headlineSmall)
                        Button(onClick = { showAddProfile = true }) { Text("إضافة") }
                    }
                    LazyColumn { items(profiles) { p ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) { Column(Modifier.padding(12.dp)) {
                            Text(p.name, style = MaterialTheme.typography.titleMedium)
                            Text("${p.platform} • ${p.groupTag} • ${p.status}")
                            TextButton(onClick = { browserUrl = platformHome(p.platform); tab = "المتصفح" }) { Text("فتح المتصفح") }
                            TextButton(onClick = { scope.launch { db.profiles().delete(p) } }) { Text("حذف") }
                        } }
                    } }
                }
                "المهام" -> {
                    Text("إنشاء مهمة", style = MaterialTheme.typography.headlineSmall)
                    OutlinedTextField(taskTitle, { taskTitle = it }, label = { Text("اسم المهمة") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(taskUrl, { taskUrl = it }, label = { Text("رابط المنشور أو الصفحة") }, modifier = Modifier.fillMaxWidth())
                    Text("المنصة: $selectedPlatform")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("auto", "instagram", "facebook", "tiktok", "youtube").forEach { p ->
                            FilterChip(selected = selectedPlatform == p, onClick = { selectedPlatform = p }, label = { Text(p) })
                        }
                    }
                    Text("الإجراءات")
                    listOf("like", "comment", "share", "follow").forEach { a ->
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Checkbox(checked = a in selectedActions, onCheckedChange = { checked -> selectedActions = if (checked) selectedActions + a else selectedActions - a })
                            Text(a)
                        }
                    }
                    Button(onClick = {
                        val detected = UrlPlatformDetector.detect(taskUrl, selectedPlatform)
                        if (detected.valid && taskTitle.isNotBlank() && selectedActions.isNotEmpty()) scope.launch {
                            db.tasks().upsert(TaskEntity(UUID.randomUUID().toString(), taskTitle, detected.normalizedUrl, selectedPlatform, selectedActions.joinToString(",")))
                            taskTitle = ""; taskUrl = ""
                        }
                    }, enabled = taskUrl.isNotBlank() && taskTitle.isNotBlank()) { Text("حفظ المهمة") }
                    Spacer(Modifier.height(8.dp))
                    Text("المهام المحفوظة")
                    LazyColumn { items(tasks) { t -> Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Column(Modifier.padding(10.dp)) { Text(t.title); Text(t.url); Text("${t.actions} • ${t.status}") } } } }
                }
                "المتصفح" -> {
                    Text("المتصفح المدمج", style = MaterialTheme.typography.headlineSmall)
                    OutlinedTextField(browserUrl, { browserUrl = it }, modifier = Modifier.fillMaxWidth(), label = { Text("الرابط") })
                    Button(onClick = { browserUrl = UrlPlatformDetector.detect(browserUrl).normalizedUrl.ifBlank { browserUrl } }) { Text("فتح الرابط") }
                    EmbeddedBrowser(browserUrl, Modifier.fillMaxSize().weight(1f))
                }
                "السجلات" -> {
                    Text("سجل التنفيذ", style = MaterialTheme.typography.headlineSmall)
                    if (logs.isEmpty()) Text("لا توجد سجلات بعد")
                    LazyColumn { items(logs) { log -> Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Column(Modifier.padding(10.dp)) {
                        Text("${log.profileName} • ${log.resultStatus}")
                        Text("${log.actionSummary} • ${log.details}")
                    } } } }
                }
            }
        }
    }
    if (showAddProfile) AddProfileDialog(onDismiss = { showAddProfile = false }, onSave = { name, platform, group ->
        scope.launch { db.profiles().upsert(ProfileEntity(UUID.randomUUID().toString(), name, platform, group)) }
        showAddProfile = false
    })
}

@Composable
private fun AddProfileDialog(onDismiss: () -> Unit, onSave: (String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }; var platform by remember { mutableStateOf("instagram") }; var group by remember { mutableStateOf("عام") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("إضافة حساب") }, text = {
        Column {
            OutlinedTextField(name, { name = it }, label = { Text("اسم الحساب") })
            OutlinedTextField(platform, { platform = it }, label = { Text("المنصة") })
            OutlinedTextField(group, { group = it }, label = { Text("المجموعة") })
        }
    }, confirmButton = { Button(onClick = { if (name.isNotBlank()) onSave(name, platform, group) }) { Text("حفظ") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

private fun platformHome(platform: String) = when (platform) {
    "instagram" -> "https://www.instagram.com/"
    "facebook" -> "https://www.facebook.com/"
    "tiktok" -> "https://www.tiktok.com/"
    "youtube" -> "https://www.youtube.com/"
    else -> "https://www.google.com/"
}
