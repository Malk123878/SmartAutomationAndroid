package com.smartautomation.android.automation

import android.net.Uri

object UrlPlatformDetector {
    private val domains = mapOf(
        "instagram" to listOf("instagram.com", "instagr.am"),
        "facebook" to listOf("facebook.com", "fb.watch", "fb.com"),
        "tiktok" to listOf("tiktok.com"),
        "youtube" to listOf("youtube.com", "youtu.be")
    )

    data class Result(val valid: Boolean, val platform: String = "unknown", val normalizedUrl: String = "", val error: String = "")

    fun detect(input: String, preferred: String = "auto"): Result {
        val raw = input.trim().let { if (it.startsWith("http://", true) || it.startsWith("https://", true)) it else "https://$it" }
        val uri = runCatching { Uri.parse(raw) }.getOrNull() ?: return Result(false, error = "صيغة الرابط غير صحيحة")
        val host = (uri.host ?: "").lowercase().removePrefix("www.").removePrefix("m.").removePrefix("vm.")
        if (host.isBlank()) return Result(false, error = "نطاق الرابط غير صالح")
        val found = domains.entries.firstOrNull { (_, hosts) -> hosts.any { host == it || host.endsWith(".$it") } }?.key ?: "unknown"
        val selected = if (preferred == "auto") found else preferred
        if (preferred != "auto" && found != "unknown" && found != preferred) return Result(false, found, error = "الرابط لا يطابق المنصة المختارة")
        if (selected == "unknown") return Result(false, error = "المنصة غير مدعومة")
        return Result(true, selected, raw)
    }
}
