package com.smartautomation.android.data

import androidx.room.*

@Entity(tableName = "profiles")
data class ProfileEntity(
    @PrimaryKey val id: String,
    val name: String,
    val platform: String = "عام",
    val groupTag: String = "عام",
    val proxyServer: String = "",
    val proxyUser: String = "",
    val proxyPass: String = "",
    val status: String = "جاهز",
    val lastError: String = "",
    val lastUsed: Long = 0L
)

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey val id: String,
    val title: String,
    val url: String,
    val platformMode: String = "auto",
    val actions: String,
    val comments: String = "",
    val commentMode: String = "random",
    val targetMode: String = "selected",
    val targetGroup: String = "",
    val targetProfileIds: String = "",
    val delayMinSeconds: Int = 10,
    val delayMaxSeconds: Int = 25,
    val status: String = "قيد الانتظار",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "task_logs")
data class TaskLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val taskId: String,
    val profileId: String,
    val profileName: String,
    val platform: String,
    val actionSummary: String,
    val commentUsed: String = "",
    val resultStatus: String,
    val errorCode: String = "",
    val details: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Dao interface ProfileDao {
    @Query("SELECT * FROM profiles ORDER BY lastUsed DESC") fun observeAll(): kotlinx.coroutines.flow.Flow<List<ProfileEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(profile: ProfileEntity)
    @Delete suspend fun delete(profile: ProfileEntity)
    @Query("SELECT * FROM profiles WHERE id=:id LIMIT 1") suspend fun get(id: String): ProfileEntity?
}

@Dao interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY createdAt DESC") fun observeAll(): kotlinx.coroutines.flow.Flow<List<TaskEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(task: TaskEntity)
    @Query("UPDATE tasks SET status=:status WHERE id=:id") suspend fun setStatus(id: String, status: String)
}

@Dao interface LogDao {
    @Query("SELECT * FROM task_logs ORDER BY createdAt DESC LIMIT 500") fun observeRecent(): kotlinx.coroutines.flow.Flow<List<TaskLogEntity>>
    @Insert suspend fun add(log: TaskLogEntity)
}

@Database(entities = [ProfileEntity::class, TaskEntity::class, TaskLogEntity::class], version = 1, exportSchema = true)
abstract class SmartDatabase : RoomDatabase() {
    abstract fun profiles(): ProfileDao
    abstract fun tasks(): TaskDao
    abstract fun logs(): LogDao
}
